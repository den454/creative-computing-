let emitters = [];
let frogSound;
let lionSound;
let birdSound;

function preload() {
  soundFormats('mp3', 'wav');

  frogSound = loadSound("frogs.mp3");
  lionSound = loadSound("lion.mp3");
  birdSound = loadSound("bird.wav");   // ← updated to .wav
}

function setup() {
  createCanvas(400, 400);
  background(255);
  textSize(16);
  text("Click near an animal to hear it", 80, 180);

  emitters.push({
    sound: frogSound,
    position: createVector(100, 200)
  });

  emitters.push({
    sound: lionSound,
    position: createVector(200, 200)
  });

  emitters.push({
    sound: birdSound,
    position: createVector(300, 200)
  });
}

function draw() {
  background(220);

  for (let emitter of emitters) {
    ellipse(emitter.position.x, emitter.position.y, 30, 30);
  }
}

function mousePressed() {
  for (let emitter of emitters) {
    let d = dist(mouseX, mouseY, emitter.position.x, emitter.position.y);
    if (d < 30 && emitter.sound.isLoaded()) {
      emitter.sound.play();
    }
  }
}

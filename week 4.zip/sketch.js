let myMarkov;
let generated;
let button1; // you can add more buttons later

function setup() {
  createCanvas(600, 400);
  background(255);
  textSize(16);
  fill(0);

  // Initialize Markov chain with 2-grams
  myMarkov = RiTa.markov(2);

  // Add sample sentences
  myMarkov.addText("The quick brown fox jumps over the lazy dog");
  myMarkov.addText("The sneaky cat leaps over the sleeping dog");
  myMarkov.addText("The mischievous rabbit hops under the quick fox");
  myMarkov.addText("The quick green frog jumps over the sparkling stream");
  myMarkov.addText("The sleepy dog curls up under the shady tree");
  myMarkov.addText("The bright yellow bird flies over the quiet lake");
  myMarkov.addText("The clever mouse scurries under the big red barn");
  myMarkov.addText("The quick fox dashes through the dark forest");
  myMarkov.addText("The quick silver fish swims under the bridge");
  myMarkov.addText("The green lizard darts over the sandy dunes");
  myMarkov.addText("The gentle horse gallops over the rolling hills");

  // Generate first sentence
  generated = generateText();

  // --- Step 5: Create character button ---
  button1 = createButton('Character 1');
  button1.position(10, height + 20);
  button1.mousePressed(() => loadCharacterText('text1.txt'));
}

function draw() {
  background(255);
  text("Generated sentence:", 20, 50);
  text(generated, 20, 80, width - 40);
}

// --- Step 3: Interactivity with mouse ---
function mousePressed() {
  generated = generateText();
}

// --- Step 4: Function to avoid repetition ---
function generateText() {
  return myMarkov.generate();  // returns a single sentence
}

// --- Step 5: Load text file for character switching ---
function loadCharacterText(filename) {
  loadStrings(filename, (result) => {
    myMarkov = RiTa.markov(2); // reset chain for new character
    myMarkov.addText(result.join(' '));

    generated = generateText();

    background(255);
    text(generated, 10, 50, width - 20, height - 20);
  });
}



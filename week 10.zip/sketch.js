// --------------------------------------
// GLOBALS
// --------------------------------------
let flowers = [];
let fountain;
let rain;

function setup() {
  createCanvas(900, 600);
  colorMode(HSB, 360, 100, 100);
  noStroke();

  // Create flowers
  for (let i = 0; i < 25; i++) {
    flowers.push(
      new Flower(
        random(50, width - 50),
        random(height * 0.45, height * 0.9),
        random(20, 40),
        floor(random(5, 12)),
        color(random(0, 360), 80, 100),
        color(50, 100, 90)
      )
    );
  }

  // Fountain in the centre
  fountain = new Fountain(width / 2, height * 0.55);

  // Rain system
  rain = new Rain();
}

function draw() {
  drawSky();
  drawGrass();

  // Flowers
  for (let f of flowers) {
    f.show();
  }

  // Fountain
  fountain.addParticle();
  fountain.update();
  fountain.show();

  // Rain
  for (let i = 0; i < 3; i++) rain.addParticle();
  rain.update();
  rain.show();
}

// --------------------------------------
// SKY + GRASS GRADIENTS
// --------------------------------------
function drawSky() {
  for (let y = 0; y <= height * 0.4; y++) {
    let inter = map(y, 0, height * 0.4, 0, 1);
    let c = lerpColor(color(207, 61, 81), color(197, 26, 98), inter);
    stroke(c);
    line(0, y, width, y);
  }
}

function drawGrass() {
  for (let y = height * 0.4; y <= height; y++) {
    let inter = map(y, height * 0.4, height, 0, 1);
    let c = lerpColor(color(100, 80, 60), color(100, 60, 40), inter);
    stroke(c);
    line(0, y, width, y);
  }
}

// --------------------------------------
// BASE CLASS: PLANT
// --------------------------------------
class Plant {
  constructor(x, y, plantSize) {
    this.x = x;
    this.y = y;
    this.plantSize = plantSize;
  }

  show() {
    // Base class does nothing visually
  }
}

// --------------------------------------
// FLOWER CLASS (inherits from Plant)
// --------------------------------------
class Flower extends Plant {
  constructor(x, y, plantSize, numPetals, petalColour, centreColour) {
    super(x, y, plantSize);
    this.numPetals = numPetals;
    this.petalColour = petalColour;
    this.centreColour = centreColour;
    this.stemColour = color(80, 92, 37);
  }

  show() {
    // Stem
    push();
    stroke(this.stemColour);
    strokeWeight(this.plantSize * 0.1);
    line(this.x, this.y, this.x, this.y + this.plantSize * 1.5);
    pop();

    // Petals
    push();
    translate(this.x, this.y);
    fill(this.petalColour);
    noStroke();
    angleMode(DEGREES);

    for (let i = 0; i < this.numPetals; i++) {
      push();
      rotate((360 / this.numPetals) * i);
      ellipse(0, -this.plantSize * 0.4, this.plantSize * 0.2, this.plantSize * 0.6);
      pop();
    }
    pop();

    // Centre
    fill(this.centreColour);
    noStroke();
    circle(this.x, this.y, this.plantSize * 0.3);
  }
}

// --------------------------------------
// PARTICLE CLASS
// --------------------------------------
class Particle {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vx = random(-1, 1);
    this.vy = random(-5, -2);

    let h = random(190, 240);
    this.colour = color(h, random(50, 100), random(80, 100));

    this.lifespan = 255;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.lifespan -= 5;
  }

  show() {
    fill(
      hue(this.colour),
      saturation(this.colour),
      brightness(this.colour),
      this.lifespan
    );
    noStroke();
    ellipse(this.x, this.y, 5);
  }

  isDead() {
    return this.lifespan <= 0 || this.y > height;
  }
}

// --------------------------------------
// FOUNTAIN CLASS (inherits behaviour)
// --------------------------------------
class Fountain {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.particles = [];
    this.gravity = 0.2;
  }

  addParticle() {
    for (let i = 0; i < 5; i++) {
      this.particles.push(new Particle(this.x, this.y));
    }
  }

  applyGravity(p) {
    p.vy += this.gravity;
  }

  update() {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      let p = this.particles[i];
      this.applyGravity(p);
      p.update();
      if (p.isDead()) this.particles.splice(i, 1);
    }
  }

  show() {
    for (let p of this.particles) p.show();
  }
}

// --------------------------------------
// RAIN SYSTEM
// --------------------------------------
class RainParticle extends Particle {
  constructor(x, y) {
    super(x, y);
    this.vx = random(-0.5, 0.5);
    this.vy = random(4, 8);
    this.colour = color(200, 70, 90);
    this.lifespan = 255;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.lifespan -= 2;
  }

  show() {
    strokeWeight(2);
    stroke(
      hue(this.colour),
      saturation(this.colour),
      brightness(this.colour),
      this.lifespan
    );
    line(this.x, this.y, this.x, this.y + 10);
  }

  isDead() {
    return this.y > height;
  }
}

class Rain {
  constructor() {
    this.particles = [];
  }

  addParticle() {
    this.particles.push(new RainParticle(random(width), random(-50, 0)));
  }

  update() {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      let p = this.particles[i];
      p.update();
      if (p.isDead()) this.particles.splice(i, 1);
    }
  }

  show() {
    for (let p of this.particles) p.show();
  }
}

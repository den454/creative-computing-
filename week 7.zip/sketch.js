let numMirrors = 8; // Number of symmetrical segments
let shape1;

function setup() {
  createCanvas(600, 600);
  angleMode(DEGREES);
  noStroke();

  // Blue object shape
  shape1 = {
    x: 100,
    y: 0,
    size: 50,
    colour: color(80, 140, 255, 180)   // soft glowing blue
  };
}

function draw() {
  background(10, 20, 40);  // deep navy background
  translate(width / 2, height / 2);

  // First kaleidoscope layer
  for (let i = 0; i < numMirrors; i++) {
    push();
    rotate((360 / numMirrors) * i);

    fill(30, 80, 200);  // strong blue
    arc(100, 0, 60, 90, 20, 120);

    scale(-1, 1);
    fill(120, 180, 255); // light blue circle
    circle(10, 10, 25);

    pop();
  }

  // Second kaleidoscope layer (object-based ellipse)
  for (let i = 0; i < numMirrors; i++) {
    push();
    rotate((360 / numMirrors) * i);

    fill(shape1.colour);
    ellipse(shape1.x, shape1.y, shape1.size, shape1.size);

    scale(-1, 1);
    ellipse(shape1.x, shape1.y, shape1.size, shape1.size);

    pop();
  }
}

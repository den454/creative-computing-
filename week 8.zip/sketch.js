let trees = [];
let numTrees = 40;

// Optional textures (upload your own later)
let barkTex;
let leafTex;

function preload() {
  // Uncomment when you upload textures:
  // barkTex = loadImage("bark.jpg");
  // leafTex = loadImage("leaves.jpg");
}

function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);
  noStroke();

  // Lighting
  ambientLight(120);
  pointLight(255, 255, 255, 0, -300, 300);

  // Generate forest
  for (let i = 0; i < numTrees; i++) {
    trees.push(new Tree(
      random(-800, 800),     // x position
      random(-800, 800),     // z position
      random(80, 200),       // trunk height
      random(40, 120)        // foliage size
    ));
  }
}

function draw() {
  background(20, 40, 60);
  orbitControl(); // rotate + zoom camera

  drawGround();

  for (let t of trees) {
    t.display();
  }
}

// ---------------------------
// GROUND PLANE
// ---------------------------
function drawGround() {
  push();
  rotateX(HALF_PI);
  fill(40, 120, 40);
  plane(3000, 3000);
  pop();
}

// ---------------------------
// TREE CLASS
// ---------------------------
class Tree {
  constructor(x, z, trunkHeight, foliageSize) {
    this.x = x;
    this.z = z;
    this.trunkHeight = trunkHeight;
    this.foliageSize = foliageSize;

    // Random colours
    this.trunkCol = color(random(100, 140), random(60, 40), random(20, 10));
    this.foliageCol = color(random(20, 120), random(150, 220), random(20, 80));
  }

  display() {
    push();
    translate(this.x, 0, this.z);

    // --- TRUNK ---
    push();
    translate(0, -this.trunkHeight / 2, 0);
    fill(this.trunkCol);
    // texture(barkTex);
    cylinder(20, this.trunkHeight);
    pop();

    // --- FOLIAGE ---
    push();
    translate(0, -this.trunkHeight, 0);
    fill(this.foliageCol);
    // texture(leafTex);
    sphere(this.foliageSize);
    pop();

    pop();
  }
}

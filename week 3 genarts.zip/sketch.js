function setup() {
  createCanvas(400, 400);
}
let compPalette = ['#ADD8E6', '#90EE90', '#FFFF66'];

function setup() {
  createCanvas(400, 400);
  noStroke();
  background(240);

  for (let i = 0; i < 5; i++) {
    drawTriangle();
    drawRectangle();
    drawCircle(); // 
  }
}

function draw() {
  // static
}

function randomPaletteColor() {
  let c = color(random(compPalette));
  c.setAlpha(random(60, 200)); 
  return c;
}

function drawTriangle() {
  fill(randomPaletteColor());
  triangle(
    random(width), random(height),
    random(width), random(height),
    random(width), random(height)
  );
}

function drawRectangle() {
  fill(randomPaletteColor());
  rect(
    random(width - 30),
    random(height - 30),
    30,
    30
  );
}

function drawCircle() {   // 
  fill(randomPaletteColor());
  circle(
    random(width),
    random(height),
    random(20, 80)         
  );
}


 



